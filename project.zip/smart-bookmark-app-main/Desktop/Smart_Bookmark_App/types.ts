export type Bookmark = {
    id: string
    created_at: string
    title: string
    url: string
    user_id: string
}
